# Code for VGA output and along with acquisition


